from getInfo import *

class bold:
    BOLD = "\033[1m"
    END = '\033[0m'


def map(roomPath, topic):
    info = getInfo(roomPath, topic)
    
    print("You are currently at,", getInfo(roomPath, "displayName"))
    print("Your travel options are:")

    for key, value in info.items():
        print(bold.BOLD + key.capitalize() + bold.END + ":", value )
    